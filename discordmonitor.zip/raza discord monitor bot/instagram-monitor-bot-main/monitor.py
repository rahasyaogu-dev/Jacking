import asyncio
import discord
import datetime
import os

from api import get_instagram_profile
from database import stop_monitor, get_notification_channel
from image_generator import generate_instagram_header


async def send_ban_embed(bot, channel_id, username, profile, tat="Auto Monitor"):
    try:
        channel = bot.get_channel(channel_id)
        if channel is None:
            channel = await bot.fetch_channel(channel_id)

        followers = profile.get('followers', 0)
        image_path = generate_instagram_header(profile)
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S IST")

        embed = discord.Embed(
            title=f"sent to the grave | @{username} 🚫",
            description=f"Followers: {followers:,} | Time Taken: {tat}",
            color=0xff3b30
        )

        file = discord.File(image_path, filename="header.png")
        embed.set_image(url="attachment://header.png")
        embed.set_footer(text=f"Banned at {now}")

        await channel.send(embed=embed, file=file)

        if os.path.exists(image_path):
            os.remove(image_path)

    except Exception as e:
        print("Ban send error:", e)


async def send_unban_embed(bot, channel_id, username, profile, tat="Auto Monitor"):
    try:
        channel = bot.get_channel(channel_id)
        if channel is None:
            channel = await bot.fetch_channel(channel_id)

        followers = profile.get('followers', 0)
        image_path = generate_instagram_header(profile)
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S IST")

        embed = discord.Embed(
            title=f"return from the grave | @{username} 🏆✅",
            description=f"Followers: {followers:,} | Time Taken: {tat}",
            color=0x2ecc71
        )

        file = discord.File(image_path, filename="header.png")
        embed.set_image(url="attachment://header.png")
        embed.set_footer(text=f"Unbanned at {now}")

        await channel.send(embed=embed, file=file)

        if os.path.exists(image_path):
            os.remove(image_path)

    except Exception as e:
        print("Unban send error:", e)


async def monitor_loop(bot, user_id, scope, monitor_id, username, type, interval):

    print("Monitor loop started for", username)

    await asyncio.sleep(5)

    was_banned = False

    while True:
        try:
            print("Checking", username)

            profile = await asyncio.to_thread(
                get_instagram_profile,
                username
            )

            if profile is None:
                await asyncio.sleep(30)
                continue

            available = profile.get("available", True)

            # BANNED
            if available is False:
                was_banned = True
                print(username, "is banned")

                if type == "ban":
                    channel_id = get_notification_channel(user_id, scope)
                    await send_ban_embed(bot, channel_id, username, profile)
                    stop_monitor(monitor_id)
                    return

            # UNBANNED
            else:
                if was_banned and type == "unban":
                    print(username, "is unbanned")
                    channel_id = get_notification_channel(user_id, scope)
                    await send_unban_embed(bot, channel_id, username, profile)
                    stop_monitor(monitor_id)
                    return

        except Exception as e:
            print("Monitor error:", e)

        await asyncio.sleep(interval * 60)


def start_monitor_task(bot, user_id, scope, monitor_id, username, type, interval):

    print("Starting monitor task for", username)

    bot.loop.create_task(
        monitor_loop(
            bot,
            user_id,
            scope,
            monitor_id,
            username,
            type,
            interval
        )
    )