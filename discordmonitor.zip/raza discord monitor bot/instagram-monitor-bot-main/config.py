import os
from dotenv import load_dotenv

load_dotenv()

OWNER_ID = int(os.getenv("OWNER_ID"))

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")

PORT = int(os.getenv("PORT", 8080))

MIN_TIME = int(os.getenv("MIN_TIME", 5))
MAX_TIME = int(os.getenv("MAX_TIME", 120))

START_IMAGE_URL = os.getenv("START_IMAGE_URL")
