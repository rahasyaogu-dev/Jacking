from api import get_instagram_profile
print(get_instagram_profile("zuck"))