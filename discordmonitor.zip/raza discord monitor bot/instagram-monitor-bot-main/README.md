
## Tech Stack

- Python
- Discord.py
- SQLite Database
- AsyncIO
- Instagram API

## Features

- Monitor account bans/unbans
- Monitor verification status
- Get profile information
- Custom monitoring intervals
- Server channel notifications
- Private bot (owner only)

## Setup

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Create a `.env` file with:
   ```
   DISCORD_TOKEN=your_discord_bot_token
   OWNER_ID=your_discord_user_id
   MIN_TIME=5
   MAX_TIME=120
   START_IMAGE_URL=optional_image_url
   ```
4. Run the bot: `python main.py`

## Usage in Server

1. Invite the bot to your Discord server
2. Use `/settime <minutes>` to set monitoring interval
3. Use `/set_channel` in the desired notification channel
4. Use `/monitor <type> <username>` to start monitoring
5. Notifications will be sent to the set channel

## Commands

- `/start` - Show help and info
- `/settime <minutes>` - Set monitoring interval- `/set_channel` - Set notification channel for server- `/monitor <type> <username>` - Start monitoring (type: ban/unban/verify)
- `/active_monitors` - View active monitors
- `/stop <monitor_id>` - Stop a monitor
- `/insta <username>` - Get profile info

## Developer

[razaog](https://t.me/razaog) | [razatools](https://t.me/razatools)
• Async Python Monitoring System
• Instagram API Requests

━━━━━━━━━━━━━━━━━━━

「 ꜰᴇᴀᴛᴜʀᴇꜱ 」

Instagram account monitoring
Ban / Unban detection
Verified badge detection
Instant Telegram notifications
Multi account monitoring
Custom monitoring interval
MongoDB database storage
Lightweight and fast bot system
Fully automated monitoring

━━━━━━━━━━━━━━━━━━━

「 ɪɴꜱᴛᴀʟʟᴀᴛɪᴏɴ 」

1 Clone Repository

``
git clone https://github.com/YOUR_USERNAME/ig-monitor.git``
``cd ig-monitor``

2 Install Requirements

``pip install -r requirements.txt``

3 Configure Bot

Edit the configuration file:

config.py

Add your credentials:

``BOT_TOKEN = "Your Telegram Bot Token"
OWNER_ID = "Your Telegram ID"
MONGO_URI = "Your MongoDB Connection String"``

4 Run The Bot

``python3 main.py``

━━━━━━━━━━━━━━━━━━━

「 ᴜꜱᴇ ᴄᴀꜱᴇꜱ 」

This bot can be used for:

• Monitoring Instagram usernames
• Detecting banned accounts
• Tracking verification badge changes
• Influencer monitoring
• Username hunting
• Automation and research

━━━━━━━━━━━━━━━━━━━

「 ꜱᴜᴘᴘᴏʀᴛ & ᴄᴏᴍᴍᴜɴɪᴛʏ 」

<p align="center">
<a href="https://t.me/pythontodayz">
<img src="https://img.shields.io/badge/Telegram-Join%20Community-blue?style=for-the-badge&logo=telegram">
</a>
</p>


━━━━━━━━━━━━━━━━━━━
