import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

from bot import setup_bot

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = 1444559911458443276  

intents = discord.Intents.default()

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)

@bot.event
async def on_ready():
    guild = discord.Object(id=GUILD_ID)
    await bot.tree.sync(guild=guild)
    print("Guild commands synced")
    print(f"Logged in as {bot.user}")

setup_bot(bot)

bot.run(TOKEN)