import discord
import asyncio
import time
import os
import datetime
from discord import app_commands, Embed

from database import (
    set_user_time,
    get_user_time,
    add_monitor,
    get_active_monitors,
    stop_monitor,
    delete_monitor,
    set_notification_channel
)

from monitor import start_monitor_task
from api import get_instagram_profile
from image_generator import generate_instagram_header

LOGO_PATH = "logo.png"

running_monitors = set()


def setup_bot(bot):

    def scope_id(interaction):
        return interaction.guild.id if interaction.guild else interaction.user.id


    @bot.tree.command(name="start", description="Show bot dashboard")
    async def start(interaction: discord.Interaction):

        embed = discord.Embed(
            title="INSTAGRAM MONITORS",
            description="Advanced Instagram Monitoring System",
            color=0x8b5cf6
        )

        embed.set_image(url="attachment://logo.png")
        file = discord.File(LOGO_PATH, filename="logo.png")

        await interaction.response.send_message(embed=embed, file=file)


    @bot.tree.command(name="insta", description="Lookup Instagram profile")
    async def insta(interaction: discord.Interaction, username: str):

        await interaction.response.defer()

        username = username.replace("@", "").strip()

        profile = await asyncio.to_thread(
            get_instagram_profile,
            username
        )

        if not profile:
            await interaction.followup.send("Profile not found")
            return

        embed = Embed(
            title=f"Instagram Profile • @{username}",
            color=0x8b5cf6
        )

        embed.add_field(name="Followers", value=f"{profile.get('followers',0):,}")
        embed.add_field(name="Following", value=f"{profile.get('following',0):,}")
        embed.add_field(name="Posts", value=f"{profile.get('posts',0):,}")

        if profile.get("profile_pic"):
            embed.set_thumbnail(url=profile["profile_pic"])

        await interaction.followup.send(embed=embed)


    @bot.tree.command(name="settime", description="Set monitoring interval")
    async def settime(interaction: discord.Interaction, minutes: int):

        scope = scope_id(interaction)

        set_user_time(
            interaction.user.id,
            scope,
            minutes
        )

        await interaction.response.send_message(
            f"Monitoring interval set to {minutes} minutes"
        )


    @bot.tree.command(name="set_channel", description="Set alert channel")
    async def set_channel(interaction: discord.Interaction):

        scope = scope_id(interaction)

        set_notification_channel(
            interaction.user.id,
            scope,
            interaction.channel.id
        )

        await interaction.response.send_message(
            f"Alerts will be sent in {interaction.channel.mention}"
        )


    @bot.tree.command(name="monitor", description="Start monitoring account")
    @app_commands.choices(type=[
        app_commands.Choice(name="Ban", value="ban"),
        app_commands.Choice(name="Unban", value="unban"),
        app_commands.Choice(name="Verify", value="verify")
    ])
    async def monitor(interaction: discord.Interaction, type: str, username: str):

        await interaction.response.defer(ephemeral=True)

        scope = scope_id(interaction)

        interval = get_user_time(
            interaction.user.id,
            scope
        )

        if not interval:
            await interaction.followup.send("Run `/settime` first.")
            return

        username = username.replace("@", "").strip()

        profile = await asyncio.to_thread(
            get_instagram_profile,
            username
        )

        if not profile:
            await interaction.followup.send("Could not fetch profile")
            return

        monitor_id = add_monitor(
            interaction.user.id,
            scope,
            username,
            type,
            profile
        )

        if monitor_id in running_monitors:
            await interaction.followup.send("Monitor already running")
            return

        running_monitors.add(monitor_id)

        start_monitor_task(
            bot,
            interaction.user.id,
            scope,
            monitor_id,
            username,
            type,
            interval
        )

        embed = Embed(
            title="Monitoring Started",
            color=0x8b5cf6
        )

        embed.add_field(name="Account", value=f"@{username}")
        embed.add_field(name="Type", value=type.upper())
        embed.add_field(name="Status", value="Monitoring")

        embed.add_field(name="Followers", value=f"{profile.get('followers',0):,}")
        embed.add_field(name="Following", value=f"{profile.get('following',0):,}")
        embed.add_field(name="Posts", value=f"{profile.get('posts',0):,}")

        embed.add_field(
            name="Started",
            value=f"<t:{int(time.time())}:T>"
        )

        await interaction.followup.send(embed=embed)


    @bot.tree.command(name="dashboard", description="View active monitors")
    async def dashboard(interaction: discord.Interaction):

        scope = scope_id(interaction)

        monitors = get_active_monitors(
            interaction.user.id,
            scope
        )

        if not monitors:
            await interaction.response.send_message("No active monitors")
            return

        embed = Embed(
            title="Active Monitors",
            color=0x5865F2
        )

        for m in monitors:
            embed.add_field(
                name=f"Monitor {m['id']}",
                value=f"@{m['username']} • {m['type']}",
                inline=False
            )

        await interaction.response.send_message(embed=embed)


    @bot.tree.command(name="delmonitor", description="Delete monitor")
    async def delmonitor(interaction: discord.Interaction, username: str):

        scope = scope_id(interaction)

        monitors = get_active_monitors(
            interaction.user.id,
            scope
        )

        for m in monitors:
            if m["username"] == username.replace("@",""):
                stop_monitor(m["id"])
                delete_monitor(m["id"])

                await interaction.response.send_message(
                    f"Monitor removed for @{username}"
                )
                return

        await interaction.response.send_message("Monitor not found")


    @bot.tree.command(name="ban", description="Ban notification")
    async def ban(interaction: discord.Interaction, username: str, tat: str):

        await interaction.response.defer()

        username = username.replace("@", "").strip()

        profile = await asyncio.to_thread(
            get_instagram_profile,
            username
        )

        if not profile:
            await interaction.followup.send("Profile not found")
            return

        followers = profile.get('followers', 0)
        image_path = generate_instagram_header(profile)

        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S IST")

        embed = discord.Embed(
            title=f"sent to the grave | @{username} 🚫",
            description=f"Followers: {followers:,} | Time Taken: {tat}",
            color=0xff3b30
        )

        file = discord.File(image_path, filename="header.png")
        embed.set_image(url="attachment://header.png")
        embed.set_footer(text=f"Banned at {now}")

        await interaction.followup.send(embed=embed, file=file)

        if os.path.exists(image_path):
            os.remove(image_path)


    @bot.tree.command(name="unban", description="Unban notification")
    async def unban(interaction: discord.Interaction, username: str, tat: str):

        await interaction.response.defer()

        username = username.replace("@", "").strip()

        profile = await asyncio.to_thread(
            get_instagram_profile,
            username
        )

        if not profile:
            await interaction.followup.send("Profile not found")
            return

        followers = profile.get('followers', 0)
        image_path = generate_instagram_header(profile)

        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S IST")

        embed = discord.Embed(
            title=f"return from the grave | @{username} 🏆✅",
            description=f"Followers: {followers:,} | Time Taken: {tat}",
            color=0x2ecc71
        )

        file = discord.File(image_path, filename="header.png")
        embed.set_image(url="attachment://header.png")
        embed.set_footer(text=f"Unbanned at {now}")

        await interaction.followup.send(embed=embed, file=file)

        if os.path.exists(image_path):
            os.remove(image_path)