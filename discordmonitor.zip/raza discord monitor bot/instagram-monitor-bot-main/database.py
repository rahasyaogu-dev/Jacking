import sqlite3
import json

DB_PATH = "instagram_monitor.db"


def get_connection():
    return sqlite3.connect(DB_PATH)


def init_db():

    conn = get_connection()
    c = conn.cursor()

    # USERS TABLE
    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER,
        guild_id INTEGER,
        time_interval INTEGER,
        notification_channel INTEGER,
        PRIMARY KEY (user_id, guild_id)
    )
    """)

    # MONITORS TABLE
    c.execute("""
    CREATE TABLE IF NOT EXISTS monitors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        guild_id INTEGER,
        username TEXT,
        type TEXT,
        active INTEGER,
        profile_data TEXT
    )
    """)

    conn.commit()

    # --- FIX OLD DATABASES (ADD MISSING COLUMNS) ---
    c.execute("PRAGMA table_info(monitors)")
    columns = [row[1] for row in c.fetchall()]

    if "guild_id" not in columns:
        c.execute("ALTER TABLE monitors ADD COLUMN guild_id INTEGER")

    conn.commit()
    conn.close()


init_db()


def get_user(user_id, guild_id):

    conn = get_connection()
    c = conn.cursor()

    c.execute(
        "SELECT user_id,guild_id,time_interval,notification_channel FROM users WHERE user_id=? AND guild_id=?",
        (user_id, guild_id)
    )

    row = c.fetchone()
    conn.close()

    if row:
        return {
            "user_id": row[0],
            "guild_id": row[1],
            "time_interval": row[2],
            "notification_channel": row[3]
        }

    return None


def set_user_time(user_id, guild_id, time_minutes):

    conn = get_connection()
    c = conn.cursor()

    c.execute(
        "INSERT OR REPLACE INTO users (user_id,guild_id,time_interval) VALUES (?,?,?)",
        (user_id, guild_id, time_minutes)
    )

    conn.commit()
    conn.close()


def get_user_time(user_id, guild_id):

    user = get_user(user_id, guild_id)

    if user:
        return user["time_interval"]

    return None


def set_notification_channel(user_id, guild_id, channel_id):

    conn = get_connection()
    c = conn.cursor()

    c.execute(
        "INSERT OR REPLACE INTO users (user_id,guild_id,notification_channel) VALUES (?,?,?)",
        (user_id, guild_id, channel_id)
    )

    conn.commit()
    conn.close()


def get_notification_channel(user_id, guild_id):

    user = get_user(user_id, guild_id)

    if user:
        return user["notification_channel"]

    return None


def add_monitor(user_id, guild_id, username, monitor_type, profile_data):

    conn = get_connection()
    c = conn.cursor()

    profile_json = json.dumps(profile_data)

    c.execute(
        "INSERT INTO monitors (user_id,guild_id,username,type,active,profile_data) VALUES (?,?,?,?,?,?)",
        (user_id, guild_id, username, monitor_type, 1, profile_json)
    )

    monitor_id = c.lastrowid

    conn.commit()
    conn.close()

    return monitor_id


def get_active_monitors(user_id, guild_id):

    conn = get_connection()
    c = conn.cursor()

    if user_id is None:
        c.execute(
            "SELECT id,user_id,guild_id,username,type,active,profile_data FROM monitors WHERE guild_id=? AND active=1",
            (guild_id,)
        )
    else:
        c.execute(
            "SELECT id,user_id,guild_id,username,type,active,profile_data FROM monitors WHERE user_id=? AND guild_id=? AND active=1",
            (user_id, guild_id)
        )

    rows = c.fetchall()

    conn.close()

    monitors = []

    for row in rows:

        profile_data = json.loads(row[6]) if row[6] else {}

        monitors.append({
            "id": row[0],
            "user_id": row[1],
            "guild_id": row[2],
            "username": row[3],
            "type": row[4],
            "active": bool(row[5]),
            "profile_data": profile_data
        })

    return monitors


def stop_monitor(monitor_id):

    conn = get_connection()
    c = conn.cursor()

    c.execute(
        "UPDATE monitors SET active=0 WHERE id=?",
        (monitor_id,)
    )

    conn.commit()
    conn.close()


def delete_monitor(monitor_id):

    conn = get_connection()
    c = conn.cursor()

    c.execute(
        "DELETE FROM monitors WHERE id=?",
        (monitor_id,)
    )

    conn.commit()
    conn.close()


def get_monitor_by_id(monitor_id):

    conn = get_connection()
    c = conn.cursor()

    c.execute(
        "SELECT id,user_id,guild_id,username,type,active,profile_data FROM monitors WHERE id=?",
        (monitor_id,)
    )

    row = c.fetchone()
    conn.close()

    if not row:
        return None

    profile_data = json.loads(row[6]) if row[6] else {}

    return {
        "id": row[0],
        "user_id": row[1],
        "guild_id": row[2],
        "username": row[3],
        "type": row[4],
        "active": bool(row[5]),
        "profile_data": profile_data
    }

def get_all_active_monitors():

    conn = get_connection()
    c = conn.cursor()

    c.execute(
        "SELECT id, user_id, guild_id, username, type, active FROM monitors WHERE active = 1"
    )

    rows = c.fetchall()

    conn.close()

    monitors = []

    for row in rows:

        monitors.append({
            "id": row[0],
            "user_id": row[1],
            "guild_id": row[2],
            "username": row[3],
            "type": row[4],
            "active": row[5],
            "interval": 5
        })

    return monitors